To run this game you need.
1.python
2.pygame
installed in your ( linux ) computer to run interminal type :-python game.py
